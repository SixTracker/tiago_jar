import java.time.LocalDateTime

class Temperatura {
    var dado:Double = 0.0
    var dtHora = LocalDateTime.now()
}